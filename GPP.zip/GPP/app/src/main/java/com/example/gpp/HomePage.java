package com.example.gpp;

import android.content.Intent;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

public class HomePage extends AppCompatActivity {
    private Button button;
    private Button camera;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_home_page );
        button=findViewById(R.id.button3);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(HomePage.this,Profile.class);
                startActivity(intent);
                finish();
            }
        });
        camera=findViewById(R.id.button);
        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    Intent myintent=new Intent();
                    myintent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivity(myintent);
                }catch(Exception e){
                    e.printStackTrace();
                }

            }
        });

    }

    public void logout(View view) {
        FirebaseAuth.getInstance ().signOut ();//logout
        startActivity ( new Intent ( getApplicationContext (),Login.class ) );
        finish ();
    }
}
